package com.cg.spring.mvc.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class FrontController {
	
	@RequestMapping(value="/getallp", method=RequestMethod.GET)
	public ModelAndView getAllCustomers() {
		ModelAndView mv=new ModelAndView("showall");
		RestTemplate template=new RestTemplate();
		List<Customer> list=template.getForObject("http://localhost:9396/getall", ArrayList.class);
		mv.addObject("customer", list);
		return mv;
		
	}
	
	@RequestMapping(value="/add", method=RequestMethod.GET)
	public ModelAndView add() {
		ModelAndView mv=new ModelAndView("addcus");
		RestTemplate template=new RestTemplate();
		mv.addObject("command", new Customer());
		return mv;
		
	}
	
	@RequestMapping(value="/addc", method=RequestMethod.POST)
	public String addCustomer(Customer c) {
		RestTemplate template=new RestTemplate();
		template.postForObject("http://localhost:9396/addall", c, String.class);
		return "redirect:/getallp";
		
	}
	@GetMapping("/upde")
	public ModelAndView updateById(@RequestParam("id")Integer id) {
		ModelAndView mv=new ModelAndView("updatec");
		mv.addObject("id", id);
		mv.addObject("command", new Customer());
		return mv;
	}
	
	@RequestMapping(value="/updatecustomer", method=RequestMethod.POST)
	public String updateCustomer(Customer c) {
	RestTemplate template=new RestTemplate();
	template.postForObject("http://localhost:9396/updateall", c, String.class);
	return "redirect:/getallp";

	}

}
