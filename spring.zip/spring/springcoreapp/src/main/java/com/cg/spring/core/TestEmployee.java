package com.cg.spring.core;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmployee {

	public static void main(String[] args) {
		//ApplicationContext ac=new ClassPathXmlApplicationContext("spring.xml");
		ConfigurableApplicationContext ac=new ClassPathXmlApplicationContext("spring.xml");
		Employee e1=ac.getBean(Employee.class);
		System.out.println(e1);
		Manager m1=ac.getBean(Manager.class);
		System.out.println(m1);
		ac.close();
	}

}
