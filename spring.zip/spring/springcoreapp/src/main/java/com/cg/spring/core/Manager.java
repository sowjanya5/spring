package com.cg.spring.core;

public class Manager {
	private int deptno;
	private String projname;
	private int projcode;
	public int getDeptno() {
		return deptno;
	}
	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}
	public String getProjname() {
		return projname;
	}
	public void setProjname(String projname) {
		this.projname = projname;
	}
	public int getProjcode() {
		return projcode;
	}
	public void setProjcode(int projcode) {
		this.projcode = projcode;
	}
	
	@Override
	public String toString() {
		return "Manager [deptno=" + deptno + ", projname=" + projname + ", projcode=" + projcode + "]";
	}
	
	
	
	

}
