package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.bean.Customer;
import com.example.demo.service.ICustomerService;

@RestController
public class CustomerRestController {
	
	@Autowired
	ICustomerService service;
	
	@GetMapping("/getall")
	public List<Customer> getAll(){
		return service.getAll();
	}
	
	@PostMapping("/addall")
	public String addAll(@RequestBody Customer c){
		service.addCustomer(c);
		return "customer details are added";
	}
	
	@PostMapping("/updateall")
	public String updateAll(@RequestBody Customer c){
		service.updateCustomer(c);
		return "customer details are updated";
	}

}
