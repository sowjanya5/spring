package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.example.demo.bean.Customer;
import com.example.demo.repository.ICustomerRepository;

@Component
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	ICustomerRepository repo;
	
	List<Customer> list=new ArrayList();
	@Override
	public List<Customer> getAll() {
    repo.findAll().forEach(list::add);
		return list;
	}
	@Override
	public void addCustomer(Customer c) {
		repo.save(c);
	}
	@Override
	public void updateCustomer(Customer c) {
			
		       if(repo.findOne(c.getId()) != null) {
				c.setName(c.getName());
				c.setMail(c.getMail());
				c.setCity(c.getCity());
			     repo.save(c);
				
			}
	}
		}
		
	

