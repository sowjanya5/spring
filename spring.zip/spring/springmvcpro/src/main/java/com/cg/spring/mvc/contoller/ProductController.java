package com.cg.spring.mvc.contoller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.spring.mvc.beans.Product;
import com.cg.spring.mvc.service.IProductService;

@Controller
public class ProductController {
	
	@Autowired
	IProductService service;
	
    @GetMapping("/getall")
	public ModelAndView getAllProducts() {
		ModelAndView mv=new ModelAndView("showall");//for viewing all products
		mv.addObject("products",service.getAllProducts()); //model..products is attribute which holds getallproduts
		return mv;
	}
	
    @GetMapping("/addp")
    public ModelAndView addProducts() {
    	ModelAndView mv=new ModelAndView("add");
    	mv.addObject("command",new Product());// command is a property of spring web mvc
    	return mv;
    }
    
    @PostMapping("/addproduct")
    public String add(Product p2) {
    	service.add(p2);
		return "redirect:/getall";
    	
    }
  
    @GetMapping("/searchproduct")
    public ModelAndView searchProducts(@RequestParam("id") int id) {
    	ModelAndView mv=new ModelAndView("search");
    	mv.addObject("product",service.searchById(id));
		return mv;
    
    }
    
    @PutMapping("/updateproduct")
    public ModelAndView updateProducts(@RequestParam("id") int id) {
    	ModelAndView mv=new ModelAndView("update");
    	mv.addObject("product",service.updateById(id));
		return mv;
    
    }
}
