package com.cg.spring.mvc.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.spring.mvc.beans.Product;

@Component
public class ProductRepoImpl implements IProductRepo{
	
    List<Product> list=new ArrayList();
	public List<Product> getAllProducts() {
		
		return list;
	}
	public void add(Product p2) {
		Product p=new Product();
		p.setId(list.size()+1);
		p.setName("oneplus");
		p.setPrice(40000);
        list.add(p);
        Product p1=new Product();
		p1.setId(list.size()+1);
		p1.setName("iphone");
		p1.setPrice(50000);
        list.add(p1);
        p2.setId(list.size()+1);
        list.add(p2);
		
	}
	public Product searchById(int id) {
		// TODO Auto-generated method stub
		for(Product p:list) {
			if(p.getId()==id) {
				return p;
			}
		}
		return null;
	}
	public Product updateById(int id) {
		for(Product p:list) {
			if(p.getId()==id) {
				return p;
			}
		}
		return null;
	}
	
	

}
