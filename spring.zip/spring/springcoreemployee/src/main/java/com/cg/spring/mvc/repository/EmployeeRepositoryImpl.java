package com.cg.spring.mvc.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.spring.mvc.beans.Employee;

@Component
public class EmployeeRepositoryImpl implements IEmployeeRepository {

	List<Employee> list = new ArrayList();

	public List<Employee> getAllEmployeeDetails() {

		return list;
	}

	public void add(Employee e) {
		Employee e1 = new Employee();
		e1.setId(list.size() + 1);
		e1.setName("sowji");
		e1.setSalary(50000);
		e1.setEmail("sowji@gmail.com");
		list.add(e1);
		Employee e2 = new Employee();
		e2.setId(list.size() + 1);
		e2.setName("bhavi");
		e2.setSalary(40000);
		e2.setEmail("sss@gmail.com");
		list.add(e2);
		e.setId(list.size() + 1);
		list.add(e);

	}

	public Employee searchById(int id) {
		for (Employee p : list) {
			if (p.getId() == id) {
				return p;
			}
		}
		return null;
	}

	public Employee updateById(int id, String name, double salary, String email) {
		for (Employee p : list) {
			if (p.getId() == id) {
				p.setName(name);
				p.setSalary(salary);
				p.setEmail(email);
				list.add(p);
				return p;
			}
		}
		return null;
	}

	public void deleteById(int id) {
		for (Employee p : list) {
			if (p.getId() == id) {
				list.remove(p);
			}
		}
	}

}
