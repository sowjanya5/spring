package com.cg.spring.mvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.spring.mvc.beans.Employee;
import com.cg.spring.mvc.repository.IEmployeeRepository;

@Component
public class EmployeeServiceImpl implements IEmployeeService {

	@Autowired
	IEmployeeRepository repo;

	public List<Employee> getAllEmployeeDetails() {

		return repo.getAllEmployeeDetails();
	}

	public void add(Employee e) {
		repo.add(e);

	}

	public Employee searchById(int id) {
		// TODO Auto-generated method stub
		return repo.searchById(id);
	}

	public Employee updateById(int id, String name, double salary, String email) {
		// TODO Auto-generated method stub
		return repo.updateById(id, name, salary, email);
	}

	public void deleteById(int id) {
		// TODO Auto-generated method stub
		repo.deleteById(id);
		
	}

}
