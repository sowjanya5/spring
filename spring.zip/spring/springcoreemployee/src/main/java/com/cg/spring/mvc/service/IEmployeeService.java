package com.cg.spring.mvc.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.spring.mvc.beans.Employee;

@Service
public interface IEmployeeService {

	List<Employee> getAllEmployeeDetails();

	void add(Employee e);

	Employee searchById(int id);

	Employee updateById(int id, String name, double salary, String email);

	void deleteById(int id);
}
