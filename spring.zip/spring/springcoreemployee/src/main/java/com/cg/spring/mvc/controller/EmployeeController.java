package com.cg.spring.mvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.spring.mvc.beans.Employee;
import com.cg.spring.mvc.service.IEmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	IEmployeeService service;

	@GetMapping("/getallemployee")
	public ModelAndView getAllEmployees() {
		ModelAndView mv = new ModelAndView("getall");// for viewing all employees
		mv.addObject("employees", service.getAllEmployeeDetails()); // model..employees is attribute which holds
																	// getallproduts
		return mv;
	}

	@GetMapping("/adde")
	public ModelAndView addEmployee() {
		ModelAndView mv = new ModelAndView("addemp");
		mv.addObject("command", new Employee());// command is a property of spring web mvc
		return mv;
	}

	@PostMapping("/addemployee")
	public String add(Employee e) {
		service.add(e);
		return "redirect:/getallemployee";

	}

	@GetMapping("/searchemployee")
	public ModelAndView searchEmployee(@RequestParam("id") int id) {
		ModelAndView mv = new ModelAndView("searchemp");
		mv.addObject("employee", service.searchById(id));
		return mv;
	}

	@GetMapping("/updateemployee")
	public String updateById(@RequestParam("id") int id, @RequestParam("name") String name,
			@RequestParam("salary") double salary, @RequestParam("email") String email) {
		service.updateById(id, name, salary, email);
		return "redirect:/getallemployee";

	}

	@GetMapping("/upde")
	public ModelAndView updateById(@RequestParam("id") int id) {
		ModelAndView mv = new ModelAndView("updateemp");
		mv.addObject("command", new Employee());// command is a property of spring web mvc
		return mv;
	}
	
	@GetMapping("/delete")
	public String deleteEmployee(@RequestParam("id")  int id) {
		service.deleteById(id);
		return "redirect:/getallemployee";
	}

}
