package com.cg.spring.jpa.springdata.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.jpa.springdata.bean.Product;
import com.cg.spring.jpa.springdata.service.IProductService;

@RestController
@ComponentScan(basePackages="com.cg.spring.jpa")
public class ProductController {
	
	@Autowired
	IProductService service;
	
	public List<Product> getAllProducts(){
		return service.getAllProducts();
		
	}
	@RequestMapping("/addproduct")
	public void insertProduct() {
		service.addProduct();
		
		}

	@RequestMapping("/updateproduct/{id}")
	public void updateProduct(@PathVariable("id") int id) {
		service.updateProduct(id);
		
	}
	
	@RequestMapping("/deleteproduct/{id}")
	public void deleteProduct(@PathVariable("id") int id) {
		service.deleteProduct(id);
		
	}
}
