package com.cg.spring.jpa.bean.springdata.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.spring.jpa.springdata.bean.Product;

@Component
@Transactional
public class ProductRepositoryImpl implements IProductRepository{

	List<Product> list;
	
	@Autowired
	EntityManager entitymanager;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Product> getAllProducts() {
		
		Query query=entitymanager.createQuery("from Product");
		list=query.getResultList();
		return list;
	}

	
	@Override
	public void addProduct() {

	Product p1 = new Product();
	p1.setId(1);
	p1.setName("oneplus");
	p1.setPrice(40000);

	entitymanager.persist(p1);
	
	
		
	}

	@Override
	public void updateProduct(int id) {
		
		Product p= entitymanager.find(Product.class, id);;
		p.setName("iphone");
		p.setPrice(50000);
		entitymanager.persist(p);
		
	}

@Override
public void deleteProduct(int id) {
	Product p= entitymanager.find(Product.class, id);

	entitymanager.remove(p);
	
}

	
}
