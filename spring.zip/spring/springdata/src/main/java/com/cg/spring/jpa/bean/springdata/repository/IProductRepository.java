package com.cg.spring.jpa.bean.springdata.repository;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.spring.jpa.springdata.bean.Product;

@Repository
public interface IProductRepository{
	
	public List<Product> getAllProducts();
	
	 void addProduct();
	 
	 void updateProduct(int id);
	 
	 void deleteProduct(int id);
	

}
