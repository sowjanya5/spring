package com.example.demo.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.bean.Product;

@Repository
public interface IProductRepository {
	
	List<Product> getAllProductDetails();
	
	Product getProductById(int id);
	
	void addProduct(int id,String name,double price);

}
