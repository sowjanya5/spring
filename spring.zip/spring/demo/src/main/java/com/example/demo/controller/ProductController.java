package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.bean.Product;
import com.example.demo.service.IProductService;

@RestController
public class ProductController {

	@Autowired
	IProductService service;
	
	@RequestMapping("/getall")
	public List<Product> getAllProducts(){
		
		List<Product> products=service.getAllProductDetails(); 
		return products;
		
	}
	
	@RequestMapping("/getbyid/{id}")
	public  Product getProductById(@PathVariable("id") int id) {
		
		
		return service.getProductById(id);
		
	}
	

	@RequestMapping("/product/{id}/{name}/{price}")
	public String addProduct(@PathVariable("id") int id,@PathVariable("name") String name,@PathVariable("price") double price) {
		service.addProduct(id,name,price);
		return "product added";
	
	
	}
	
}
