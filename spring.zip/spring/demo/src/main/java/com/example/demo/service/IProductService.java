package com.example.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.bean.Product;

@Service
public interface IProductService {
	
List<Product> getAllProductDetails();
	
	Product getProductById(int id);

	void addProduct(int id,String name,double price);
}
