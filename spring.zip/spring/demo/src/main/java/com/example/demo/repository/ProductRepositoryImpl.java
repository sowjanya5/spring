package com.example.demo.repository;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Component;

import com.example.demo.bean.Product;

@Component
public class ProductRepositoryImpl implements IProductRepository{

	List<Product> list=new ArrayList();
	@Override
	public List<Product> getAllProductDetails() {
		Product p=new Product();
		p.setId(list.size()+1);
		p.setName("oneplus");
		p.setPrice(40000);
		list.add(p);
		Product p1=new Product();
		p1.setId(list.size()+1);
		p1.setName("iphone");
		p1.setPrice(50000);
		list.add(p1);
		return list;
	}

	@Override
	public Product getProductById(int id) {
		for(Product p:list) {
			if(p.getId()==id) {
				return p;
			}
		}
		return null;
	}

	@Override
	public void addProduct(int id,String name,double price) {
		
		Product p=new Product();
		p.setId(id);
		p.setName(name);
		p.setPrice(price);
		list.add(p);
	}



}
